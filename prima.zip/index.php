<html>
<head>
<title>Web Programming</title>
</head>

<body>
<h1>Web Programming</h1>



<p><a href="syntax.php"> Simple Syntax</a>
  <br>
  <br>
  <a href="yourname.htm">Whats Your Name</a><br>
  <a href="linking.htm">Linking</a><br>
<a href="yourinfo.html">Whats Your Info</a><br>
<a href="favorites.htm">Favorites
</a><br>
<br> 
<a href="rollem.php">Conditionals
</a><br>
<a href="nameGame.html">Name Game</a><br> 
<a href="favoritesSwitch.htm"> Favorites using Switch</a></p>
<p><a href="arrays.php">Arrays</a><br>
    <a href="studentArray.php">Exercise -- Student Array</a><br>
    <a href="distance.htm">Multi-Dimensional Array</a><br>
    <a href="loops.php">Loops</a><br>
    <a href="sportsTeams.php"> Sports Teams</a></p>
<p><a href="strings.php">Strings</a><br>
<a href="stringExercise.html">String Exercise</a> (find first and last name when separated by a comma - mitchell,rick)<br>
<a href="stringExercise2.html">String Exercise 2</a> (find multiple names when separated by a comma - bill,mary,sam,willy)</p>
<p><a href="functions.php">Functions</a><br>
  <a href="changeSign.html"> Change the Sign</a><br>
  <a href="tempConvert.html">Extra Credit - Temperature Conversion</a><br>
  <a href="walterWilma.html">Who Wins?</a><br>
  <a href="largerTest.html">Find Larger</a></p>
<p><a href="include.php">Sample Include</a><br>
<a href="sessionExample.html">Sessions</a><br>
  <br>
  <a href="add_cookie.php">Add a Cookie</a><br>
  <a href="check_cookie.php">Check for Cookie</a><br>
  <a href="change_cookie.php">Change a Cookie</a><br>
  <a href="delete_cookie.php">Delete Cookie</a><br>
<a href="redirect_cookie.php">Redirect Based on Cookie</a><br>
<br>
<a href="emailSimple.php">Simple Email</a><a href="emailComplex.php"><br>
Complex Email</a><br>
<br>
<a href="errors.php">Error</a> <br>
 <a href="die.php">Die with Error</a><br>
<a href="testSign.html">Catch / Throw</a></p>
<p><a href="customerList.php">List Customers</a><br>
<a href="customer_list3.php">Update  Customer</a><br>
  <a href="source_list3.php">Update Source</a><br>
  <a href="dropDown.html">Sample Dropdown<br>
  </a><br>
  <a href="customerUpdateEdits.php"> Customer Form with Dynamic Dropdown</a><br>
  <a href="statesList.php"> List and Search States</a><br>
  <a href="cityList.php"> List and Search World Cities - Alpha</a> <br>
<a href="cityListS.php"> List and Search World Cities - Population</a> </p>

<p><a href="customer_list4.php">Customer Update with  Last ID</a><br></p>

<p><a href="handlingEvents.html">Sample Events</a><br>
  <a href="simpleSyntax.html">variables and operators</a><br>
  <a href="alerts.html">alerts</a><br>
  <a href="simpleFunctions.html">functions</a><br>
  <a href="functions2.html">called functions</a><br>
  <a href="whatsmyname2.html">full name function </a><br>
  <a href="whatsmynameSample.html">sample form for lab</a><br>
 
  <a href="whatsmyname.html">full name function called from button</a><br>
  <a href="formName.html">full name function using form fields called from submit button</a></p>
  
<p><a href="arraysLoops.html"> arrays and loops</a><br>
  <a href="javascriptExamples.html"> sample javascript routines</a><br>
  <a href="slideshow.html"> sample slideshow</a><br>
  <a href="javascriptjs.html"> javascript using js file</a><br>
  <a href="daysMonths.html"> days/months</a><br>
  <a href="getElement.html"> get element by id</a><br>
  <a href="handlingEvents.html"> </a><br>
  <a href="domExamples.html"> using the dom</a><br>
  <a href="whichButton.html"> which button</a><br>
  <a href="iceCreamTemplate.html"> favorite ice cream - template</a></p>
 
  <p><a href="iceCream.html"> favorite ice cream</a></p>

  <a href="addNode.html">add node</a><br>
  <a href="deleteNode.html">delete node</a>
  <br>
  
<p><a href="family.xml">sample xml</a><br>
  <a href="family2.xsl">complex xsl</a><br>
  <a href="familyLinked2.xml">linked xsl</a><br>
  <br>

  <a href="ajax_getTime.html">Whats the Time</a><br>
  <a href="ajax_readReturn.html">How Long</a><br>
   <a href="autoFill.html">Auto Fill</a></p>

<p><a href="hideMe.htm">JQuery - Hide Me - pre install</a><br>
	<a href="hideMe2.htm">JQuery - Hide Me - post install</a><br>
	<a href="selectors.html">Selectors that hide</a><br>
	<a href="selectors2.html">Selectors that change</a><br>
	<a href="selectors3.html">Selectors using mouseovers</a><br>
	<a href="selectors4.html">Selectors using double-click</a><br>
	<a href="selectors5.html">Selectors using mouseouts</a><br>
	<a href="lab15.html">Sample html for selector lab</a></p>

<p><a href="css.html">Change CSS</a><br>
  	<a href="append.html">Append HTML</a><br>
  	<a href="heightWidth.html">Height/Width</a><br>
  	<a href="fade.html">Fade</a><br>
  	<a href="callBack.html">Call Back</a><br>
  	<a href="slidePanel.html">Slide Panel</a><br> 
  	<a href="animate.html">Animate</a><br>
  	<a href="no_conflict.html">No Conflict</a>
 	<a href="ajaxCall.html">Ajax Call from jQuery</a></p>
 
<p><a href="callPopUp.html">Calling a Javascript PopUp</a><br>
	<a href="cssPopup.htm">Calling a CSS PopUp</a></p>

<p><a href="checkMobile.php">Check for Mobile Device</a>
</p>

</body>
</html>
