<html>
<head>
<title>Your Picks</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h1>Your Picks</h1>
<p>
<?php 
$color = $_REQUEST["color"];
$shape = $_REQUEST["select"];
print "<h3>You like $color $shape</h3>";

?>
</p>
</body>
</html>
