<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<p>&nbsp;</p>
<p>
  <?php 


function theWinner($who,$q) {

	return substr_count($who,$q);	

} // end function

$walter = strtolower($_REQUEST['walter']);
$wilma = strtolower($_REQUEST['wilma']);

$walterCnt = theWinner($walter,"w");
$wilmaCnt = theWinner($wilma,"w");

if ($walterCnt > $wilmaCnt) {
	echo "<h3>Walter Wins!</h3>";
}

if ($walterCnt < $wilmaCnt) {
	echo "<h3>Wilma Wins!</h3>";
}

if ($walterCnt == $wilmaCnt) {
	echo "<h3>Nobody Wins!</h3>";
}

?>
</p>
<p><a href="walterWilma.html">return</a></p>
</body>
</html>
