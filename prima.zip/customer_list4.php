<html>
<head>
<title>List Customers</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

<h1>List Customers</h1>
<p><br>
  <br>
  
  
  <?php

// this connects To database
include('connectDb.php');


// write a query
$query = "select * from cusTab order by cusLast, cusFirst";
// execute the query using a php function
$result = mysql_query($query);
// determine how many rows returned using function
$num = mysql_num_rows($result);
echo "There are currently $num customers on file<br><br>";

// start a table
echo "<table cellpadding=\"5\" cellspacing=\"3\" border=\"0\">" ;
// print headings
echo "<tr bgcolor=\"#cccccc\"><td><b><u>ID</b></u></td><td><u>First Name</u></td><td><u>Last Name</u></td><td><u>Street</u></td><td><u>City</u></td><td colspan=2 align=center><u>Action</u></td></tr>";

// use while loop and function to retrieve all rows
while ($row = mysql_fetch_array($result)) {
	$cusID = $row['cusID'];
	$cusFirst = $row['cusFirst'];
	$cusLast = $row['cusLast'];
	$cusStreet = $row['cusStreet'];
	$cusZip = $row['cusZip'];

	echo "<tr><td><b>$cusID</b></td>";
	echo "<td>$cusFirst</td>";
	echo "<td>$cusLast</td>";
	echo "<td>$cusStreet</td>";
	echo "<td>$cusZip</td>";
	echo "<td><a href=\"customer_update4.php?action=u&id=";
	echo $cusID;
	echo "\">Change</a></td>";	
	echo "<td><a href=\"customer_action4.php?action=d&id=";
	echo $cusID;
	echo "\">Delete</a></td></tr>";	
	
}
// close table
echo "</table>";

?>
<br><br>
<a href="customer_update4.php?action=a">Add a Customer</a>
<br>
<br>
<p><a href="index.php">Return </a></p>
</body>
</html>
