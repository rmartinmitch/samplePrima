<html>
<head>
<title>sample incluce</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h2>Sample Include </h2>
<p> 

<?php 
include('includeMe.php');
?>

</p>
<p><a href="index.php">Return</a></p>
<p>&nbsp;</p>
<p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p></body>
</html>
