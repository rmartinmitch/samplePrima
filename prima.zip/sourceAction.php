<html>
<head>
<title>update source</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h1>Update Source</h1>
<p>&nbsp;</p>
<?php 

// this connects To database
include('connectDb.php');


$srcName = $_REQUEST["srcName"];
$srcComment = $_REQUEST["srcComment"];

$dt = date('Y-m-d');

$query = "insert into srcTab values (
	null, 
	'$srcName', 
	'$srcComment', 
	'$dt', 
	null
)";

mysql_query($query) or
	die(mysql_error());

echo "<h4>Source >> " . $srcName . " - added</h4>";

?>
<br>
<p><a href="sourceAdd.php">Return</a></p>
<p>&nbsp; </p>
</body>
</html>
