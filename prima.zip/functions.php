<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>functions</title>
</head>

<body>

<?php

// php has many predefined functions

//rounding
$rounded = round(124.5678, 2);
echo "<h4>Rounded answer is: " . $rounded. "</h4>";
 
$x = 123.5678;
$y = 1;
$rounded = round($x, $y);
echo "<h4>Rounded answer is: " . $rounded . "</h4>";
 
//the date function
echo "<h4>Date is: " . date("Y-m-d") . "</h4>";

echo "<h4>Date is: " . date("F m, Y") . "</h4>";

echo "<h4>Date is: " . date("F m, Y g:i a e") . "</h4>";

echo "<h4>Seconds since the unix epoch: " . date("U") . "</h4>";


//square root
echo "<h4>Square root: " . sqrt(24) . "</h4>";

// rounded?





// add round function 
echo "<h4>Square root rounded: " . round(sqrt(24),3) . "</h4>";




// functions are excuted when called
function helloWorld() {
echo "<h4>Hello World</h4>";
}

helloWorld();
helloWorld();




//usually return a value
function helloMars() {
return "Mars";
}

echo "<h4>Hello " . helloMars() . "</h4>";



//usually accept a parm
//here set first character upper
function helloPlanet($wanderer) {
return ucwords(strtolower($wanderer));
}

echo "<h4>Hello " . helloPlanet("PLUTO") . "</h4>";
echo "<h4>Hello " . helloPlanet("saturn") . "</h4>";



//accept 3 parms - amount, discount and tax
//calculate total due
function calculate_total ($amt, $disc, $tax) {
$total = ($amt - $disc);
$total = $total + ($total * $tax);
return round($total, 2);
} // end function
 
// here call it with 3 variables 
$amt = 1424;
$disc = 142.4;
$tax = .05;        
$owed = calculate_total($amt, $disc, $tax );
echo  "<h4>Amount owed is: " . $owed . "</h4>";




//here call it directly
$owed = calculate_total(750,15.50,.04);
echo  "<h4>Amount owed is: " . $owed . "</h4>";

?>
 

<p>&nbsp;</p>
<p><a href="index.php">return</a></p>
</body>
</html>
