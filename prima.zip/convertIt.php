<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<p>Temperature Conversion</p>
<p>
  <?php 

//*****************************************************************
// This function calculates Fahrenheit or Celcius based on a parm
//*****************************************************************
function findTemp($type,$temp) {

	if ($type == 'c') {
		$holdTemp = (($temp - 32) / 9) * 5;
	} else {
		$holdTemp = (($temp * 9) / 5) + 32;
	} // end if
	return $holdTemp;	
} // end function

$temp = $_REQUEST['temp'];
$type = $_REQUEST['type'];

$theTemp = round(findTemp($type,$temp),1);

if ($type == 'f') {
	echo "You converted " . $temp . " Celcius to " . $theTemp . " Fahrenheit<br>"; 
	} else {
	echo "You converted " . $temp . " Fahrenheit to " . $theTemp . " Celcius<br>"; 
	} // end if
	

?>
</p>
<p><a href="tempConvert.html">return</a></p>
</body>
</html>
