<?php 
setcookie('csc401_test','');
setcookie('csc401_test2','',time()-360);
?>
<html>
<head>
<title>add cookie</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h1>Delete Cookie<br>
</h1>
<p><a href="index.php">Return </a></p>
<p>&nbsp; </p>
</body>
</html>
