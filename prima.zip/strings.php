<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>strings</title>
</head>

<body>
<p>Strings </p>
<?php 


//simple strings
$first = "Rick";
$last = "Mitchell";




//concatenating a string
$name = $first . " " . $last;
echo "$name <br>";




// or
echo $first . " " . $last . "<br>";




// or
echo "Rick " . $last . "<br><br>";




//single quotes are actual
//double quotes are interpolated
//so in the first example, it prints the actual text
//in the second it treats it like a variable
$test = "some text";
echo 'test is $test <br>';
echo "test is $test <br><br>";




//escape characters change how text fields in double quotes act
echo "test is \$test <br>";
echo "here is a backslash \\ and a dollar sign \$<br>";
echo "\n for a newline and \r for carriage return<br><br>";




//we saw a string function
echo strtolower("HELLO WORLD") . "<br>";




//and a string test
$x = "test";
if (!is_numeric($x)) {
	echo $x . " is NOT a number<br>";
}


// here are some more
// why does it do this?
$x = '<this is a string with tags>';
echo "where did it go? " . $x . "<br>";
echo strip_tags($x) . "<br>";



//adding slashes for database
$x = 'string with \ and "';
echo $x . "<br>";
echo addslashes($x) . "<br><br>";




//test a srring length
$testString = "abcdefghijklmnop";
$x = strlen($testString);
echo "$x characters in $testString <br>";




//this finds the position of the @
//first we assign the name to a variable named $x
//then we search for the position of the @
//notice where it finds it. why?
$x = "rick@mitchell";
$y = strpos($x,"@");
echo "the @ is at $y <br>";



//so the position of the $ is at $y
//now we can pull off the first name up to that postion
//we need to also give it the starting position
//the function counts the first position as 0
//so we start at 0 and go to $y
echo substr($x,0,$y);



?>
</body>
</html>
