<?php
//a function to see if a number is positive
function checkPositive($chkMe)
  {
  if($chkMe < 0)
    {
    throw new Exception("That number is not positive");
    }
  return true;
  }

//trigger exception in a "try" block
try
  {
  checkPositive($_REQUEST["testIt"]);
  //this will be displayed if the number is 
  echo 'congrats on thinking positive';
  }

//catch exception
catch(Exception $e)
  {
  echo 'Message: ' .$e->getMessage();
  }
?> 