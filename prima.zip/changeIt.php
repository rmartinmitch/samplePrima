<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>change sign</title>
</head>

<body>
<p>Change the Sign</p>

<p>
  <?php 

function signChange ($changeIt) {
$changeIt = $changeIt * -1;
return $changeIt;
} // end function

$changeIt = $_REQUEST['changeIt'];

if (is_numeric($changeIt)) { 
	echo "<h4>The new number is: " . signChange($changeIt) . "</h4>";
} else {
	echo "<h4>Is this too tough for you?</h4>";
}
	

?>
</p>
<p><a href="changeSign.html">return</a></p>
</body>
</html>
