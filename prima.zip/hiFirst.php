<html>
<head>
<title>Hi User</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

<?php 
$lastName = $_REQUEST["lastName"];
$firstName = $_REQUEST["firstName"];
$city = $_REQUEST["city"];
$surprise = $_REQUEST["surprise"];

print "<h4>Hi There " . $firstName . " " . $lastName . " from " . $city . " " . $surprise . "</h4>";
?>

<a href="yourinfo.html">return</a>
</body>
</html>
