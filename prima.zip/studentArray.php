<html>
<head>
<title>StudentArray</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h4>Student Array </h4>

<?php 


// a student associative array
$student["firstName"] = "Bill";
$student["lastName"] = "Bo Bob";
$student["city"] = "Cadiz";
$student["state"] = "Ohio";
$student["age"] = 20;
$student["major"] = "Phys Ed";

echo "student information<br>";
print_r ($student);

?>
<br><br>
<a href="index.php">return</a> 
</body>
</html>
