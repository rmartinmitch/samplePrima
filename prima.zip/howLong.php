<?php

//get the q parameter from URL
$q=$_GET["q"];

//get the lenth of the value
$response = strlen($q);

//output the response
echo $response;
?>
