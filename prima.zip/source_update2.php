<?php

// this connects To database
include('connectDb.php');

// read the form field
$action = $_REQUEST["action"];

// if this is an add, set all the fields to null
if ($action == 'a') {
	$srcID = null;
	$srcName= null;
	$srcComment= null;
	
 } else {
// read the variable to retrieve the id
	$id = $_REQUEST["id"];
// for an update, read the record and set all fields to the correct valuae
	 	$query = "select * from srcTab where srcID = $id";
		$result = mysql_query($query) 
			or die(mysql_error());
		$row = mysql_fetch_array($result);
		$srcName = $row['srcName'];  
		$srcComment = $row['srcComment'];  
} // end if

?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Customer Entry</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

</head>

<body>
<h1>Please Enter Source Information</h1>
<form action="sourceAction.php" method="get" name="form1" onSubmit="MM_validateForm('fname','','R','lname','','R','address','','R','city','','R','state','','R','zip','','RisNum','email','','RisEmail','phone','','RisNum');return document.MM_returnValue">
  <table width="59%" border="0" cellspacing="0" cellpadding="5">
    <tr> 
      <td width="24%"><font size="4">Source</font></td>
      <td width="76%"><input name="srcName" type="text" id="srcName" value="<?php echo $srcName;?>" size="25" maxlength="25"></td>
    </tr>
    <tr>
      <td><font size="4">Comment</font></td>
      <td><label>
        <textarea name="srcComment" id="srcComment" cols="45" rows="3"><?php echo $srcComment;?></textarea>
      </label></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td><input type="submit" name="Submit" value="Submit"></td>
    </tr>
  </table>
</form>
<p><a href="index.php">Return </a></p>
</body>
</html>
