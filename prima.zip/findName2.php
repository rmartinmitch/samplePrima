<html>
<head>
<title>string testing</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h1>String Results
</h1>
  <br>
 <?php 
$yourName = $_REQUEST["yourName"];
// set the initial string length
$len = strlen($yourName);

// this assumes you don't have a blank name, which you could check for
while ($len > 0) {
// check if there is a comma
	if (strpos($yourName, ",")) {
// if found, extract the part to the left
// now grab the next bit to the right, reset yourName and add 1 to the counter
		echo substr($yourName,0,strpos($yourName, ",")) . "<br>";	
		$yourName = substr($yourName,strpos($yourName, ",")+1);		
		$cnt++;
	} else {
// if no comma, set len to 0 to kill loop
// but there is one name left with no commas, so ....
		echo $yourName . "<br><br>";	
		$cnt++;
		$len = 0;	
	}
}
// display the total
echo $cnt . " names found";




?>

<p><a href="stringExercise2.html">return</a> </p>
</body>
</html>
