<html>
<head>
<title>Calculate Distance</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h1>The Distance Is:</h1>

<?php

$cityA = $_REQUEST["cityA"];
$cityB = $_REQUEST["cityB"];

$indy = array (
  "Indianapolis" => 0,
  "New York" => 648,
  "Tokyo" => 6476
  );
$ny = array (
  "Indianapolis" => 648,
  "New York" => 0,
  "Tokyo" => 6760
  );
$tokyo = array (
  "Indianapolis" => 6476,
  "New York" => 6760,
  "Tokyo" => 0
  );

//set up master array
$distance = array (
  "Indianapolis" => $indy,
  "New York" => $ny,
  "Tokyo" => $tokyo
  );

$result = $distance[$cityA][$cityB];
print "<h3>The distance between $cityA and $cityB is $result miles.</h3>";

?>
 
<p> <a href="distance.htm">Return</a></p> </p>
<p>&nbsp;
<p>&nbsp; </p>
</body>
</html>
