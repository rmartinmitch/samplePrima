<?php
$cookieValue = $_REQUEST[cookieValue]; 

setcookie('csc401_test2',$cookieValue, time()+(3600 * 24 *90), null, null);
?>

<html>
<head>
<title>add cookie</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h1>Set Cookie<br>
</h1>
<p><a href="index.php">Return </a></p>
<p>&nbsp; </p>
</body>
</html>
