<html>
<head>
<title>Syntax</title>
</head>

<?php

// some code goes here

?>





<?php

print "Hello World <br>";




echo "Hello World <br><br>";




echo "<h1>Hello World</h1>";




// link
echo "<a href=http://www.endicott.edu>Go Gulls</a><br><br>";




// table
echo "<table border=1> <tr>";
echo "<td>a</td>";
echo "<td>b</td>";
echo "</tr></table><br><br>";




//variables
$myName = "Rick";
echo "$myName <br><br>";




$x = 5;
$y = 6;
$z = $x + $y;
echo $z;
echo "<br><br>";




echo $x / $y;
echo "<br>";
echo $x - $y;
echo "<br>";
echo $x % $y;
echo "<br>";
echo $z++;
echo "<br>";
echo $z--;
echo "<br>";



echo "$x + $y";
echo "<br>";




echo $x + $y . "<br>";


$z = $x + $y;
echo $x . " plus " . $y . " equals " . $z;

?>

<body>
</body>
</html>
