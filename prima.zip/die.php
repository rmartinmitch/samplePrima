<?php

if(!file_exists("hypothetical.txt"))
  {
  die("sorry, the hypothetical file does not exist");
  }
else
  {
  $file=fopen("hypothetical.txt","r");
  }
?> 