<head>

<title>Form Feedback</title>

</head> 

<body>



<?php



$url = $_REQUEST['nameValue']; //can substitute $_REQUEST with $_GET



//$key = 'olivia'; // Your API key



function virustotal_scanurl($url, $key)

{

	// Desc: Submits URL to Virus Total to scan. Returns Virus Total's scan ID 

	// if successful, otherwise false.

	

	// $key: API key

	// $url: the url you want to scan

	

	// Author: Kenny Lyons aka ih8censorship

	// Website: http://pasture.sourceforge.net

	

	$url = 'http://www.virustotal.com/api/scan_url.json';

	$fields = array('url'=>$url, 'key'=>$key);

	$fields_string='';

	foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }

	$fields_string=rtrim($fields_string,'&');

	

	$ch = curl_init();



	curl_setopt($ch,CURLOPT_URL,$url);

	curl_setopt($ch,CURLOPT_POST,count($fields));

	curl_setopt($ch,CURLOPT_POSTFIELDS,$fields_string);

	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

	

	$result = curl_exec($ch);



	curl_close($ch);

	

	$result = json_decode($result, true);

	

	if($result['result']=="1"){

		return $result['scan_id'];

	} else {

		return false;

	}

	

}



function virustotal_geturlreport($key,$resource,$scan=false)

{



	// Desc: Uploads or downloads a URL to Virus Total to be scanned. If URL was previously uploaded

	// will output report of URL. If $scan is set to "1" will return Virus Total's scan ID which can

	// be used to retrieve the report at a later date.

	

	// $key: API key

	// $resource: A URL, file hash, or scan_id

	// $scan: Optional. If set to "1" URL will be submitted for analysis if it hasen't already been analyized

	

	// Author: Kenny Lyons aka ih8censorship

	// Website: http://pasture.sourceforge.net

	

	$url = 'http://www.virustotal.com/api/get_url_report.json';

	$fields = array('resource'=>$resource, 'key'=>$key,'scan'=>$scan);

	$fields_string='';

	foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }

	$fields_string=rtrim($fields_string,'&');

	

	$ch = curl_init();



	curl_setopt($ch,CURLOPT_URL,$url);

	curl_setopt($ch,CURLOPT_POST,count($fields));

	curl_setopt($ch,CURLOPT_POSTFIELDS,$fields_string);

	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

	

	$result = curl_exec($ch);



	curl_close($ch);

	

	$result = json_decode($result, true);

	

	if($scan && $result['result']=="0")

	{

		return $result['scan_id'];

	} 

	else 

	{

		return $result;

	}

	

}



?>





<p><a href="thesisForm.php">Return</a></p>

</body>

</html>





