<?php

$file=fopen("hypothetical.txt","r");

?> 