<html>
<head>
<title>update customer</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h1>Customer Update</h1>
<p>&nbsp;</p>
<?php 

// this connects To database
include('connectDb.php');

$action = $_REQUEST["action"];
$id = $_REQUEST["id"];

$cusLast = $_REQUEST["cusLast"];
$cusFirst = $_REQUEST["cusFirst"];
$cusZip = $_REQUEST["cusZip"];
$cusStreet= $_REQUEST["cusStreet"];
$cusSex = $_REQUEST["cusSex"];
$cusSource = $_REQUEST["cusSource"];
$cusAge= $_REQUEST["cusAge"];
$cusMM = $_REQUEST["cusMM"];
$cusDD = $_REQUEST["cusDD"];
$cusYY = $_REQUEST["cusYY"];
$cusBirth = $cusYY . "-" . $cusMM . "-" . $cusDD; 
$cusComment = $_REQUEST["cusComment"];

$dt = date('Y-m-d');

// here I test the parm
// the action I take depends on if the parm is a(dd) or u(pdate)
if ($action == 'a') {
	$query = "insert into cusTab values (
		null, 
		'$cusLast', 
		'$cusFirst', 
		'$cusZip', 
		'$cusStreet', 
		'$cusSex', 
		'$cusSource', 
		'$cusAge', 
		'$cusBirth',
		'$cusComment',
		'$dt', 
		null
	)";

	mysql_query($query) or
	die(mysql_error());

	echo "<h3>Thanks " . $cusFirst . " " . $custast . " for entering your information. A confirming email has been sent to your listed email address.</h3>";

	$to = 'rmitchel@endicott.edu';
	$subject = 'Welcome ' . $cusFirst;
	$body = "Thank you for registering\nYou may now use your email account for purchases\nWe hope you enjoy our services\n";

mail ($to, $subject, $body);


}

// now check for an update
// I will use a set query to update the changed fields
// I also update the changed date field 
if ($action == 'u') {
	$query = "update cusTab
		set cusLast = '$cusLast',
		cusFirst = '$cusFirst', 
		cusZip = '$cusZip', 
		cusStreet = '$cusStreet', 
		cusSex = '$cusSex', 
		cusSource = '$cusSource',
		cusAge = '$cusAge',
		cusBirth = '$cusBirth',
		cusSource = '$cusSource',
		cusComment = '$cusComment ',
		cusUpdated = '$dt' 
		where cusID = '$id'";
	mysql_query($query) or
		die(mysql_error());
	print "<h3>Update Successful</h3>";
} // end u

if ($action == 'd') {
// this is a delete
// so perform a delete query
		$query = "delete from cusTab
		where cusID = '$id'";
		$result = mysql_query($query)
			 or die("query failed:" . mysql_error());
	print "<h4>Delete Successful</h4>";
} 

?>
<br>
<p><a href="customer_list3.php">Return</a></p>
<p>&nbsp; </p>
</body>
</html>
