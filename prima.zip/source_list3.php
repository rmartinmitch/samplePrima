<html>
<head>
<title>List Source</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

<h1>List Sources</h1>
<p><br>
  <br>
  
  
<?php

// this connects To database
include('connectDb.php');

mysql_connect($hostname,$username, $password) OR DIE ("Connection Failed");
mysql_select_db($dbname);

// write a query
$query = "select * from srcTab order by srcName";
// execute the query using a php function
$result = mysql_query($query);
// determine how many rows returned using function
$num = mysql_num_rows($result);
echo "There are currently $num sources on file<br><br>";

// start a table
echo "<table cellpadding=\"5\" cellspacing=\"3\" border=\"0\">" ;
// print headings
echo "<tr bgcolor=\"#cccccc\"><td><b><u>ID</b></u></td><td><u>Source</u></td><td colspan=2 align=center><u>Action</u></td></tr>";

// use while loop and function to retrieve all rows
while ($row = mysql_fetch_array($result)) {
	$srcID = $row['srcID'];
	$srcName = $row['srcName'];

	echo "<tr><td><b>$srcID</b></td>";
	echo "<td>$srcName</td>";
	echo "<td><a href=\"source_update3.php?action=u&id=";
	echo $srcID;
	echo "\">Change</a></td>";	
	echo "<td><a href=\"source_action3.php?action=d&id=";
	echo $srcID;
	echo "\">Delete</a></td></tr>";	
	
	
}
// close table
echo "</table>";

?>
<br><br>
<a href="source_update3.php?action=a">Add a Source</a>
<br>
<br>
<p><a href="index.php">Return </a></p>
</body>
</html>
