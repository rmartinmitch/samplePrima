<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Customer Entry</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

</head>

<body>
<h1>Please Enter Source Information</h1>
<form action="sourceAction.php" method="get" name="form1" onSubmit="MM_validateForm('fname','','R','lname','','R','address','','R','city','','R','state','','R','zip','','RisNum','email','','RisEmail','phone','','RisNum');return document.MM_returnValue">
  <table width="59%" border="0" cellspacing="0" cellpadding="5">
    <tr> 
      <td width="24%"><font size="4">Source</font></td>
      <td width="76%"><input name="srcName" type="text" id="srcName" size="25" maxlength="25"></td>
    </tr>
    <tr>
      <td><font size="4">Comment</font></td>
      <td><label>
        <textarea name="srcComment" id="srcComment" cols="45" rows="3"></textarea>
      </label></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td><input type="submit" name="Submit" value="Submit"></td>
    </tr>
  </table>
</form>
<p><a href="index.php">Return </a></p>
</body>
</html>
