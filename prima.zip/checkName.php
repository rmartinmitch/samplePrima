<html>
<head>
<title>name game</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h1>

<?php 

$nameValue = $_REQUEST["nameValue"];

print "<h4>You entered $nameValue</h4>";

if (is_numeric($nameValue)) {
	print "<h4>Thats a number</h4>";
}

if (strtolower($nameValue) == "rick") {
	print "<h4>Its your name!</h4>";
} else {
	print "<h4>Its not your name</h4>";
}


?>
</h1>
<p><a href="nameGame.html">return</a></p>
</body>
</html>
