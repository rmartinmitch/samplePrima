<html>
<head>
<title>Your Picks</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h1>Your Picks</h1>
<p>
<?php 
$color = $_REQUEST["color"];
$shape = $_REQUEST["select"];

switch ($color) {
    case 1:
        $seeColor = "red";
        break;
    case 2:
        $seeColor = "green";
        break;
    case 3:
        $seeColor = "blue";
        break;
}

switch ($shape) {
    case "a":
        $seeShape = "squares";
        break;
    case "b":
        $seeShape = "circles";
        break;
    case "c":
        $seeShape = "triangles";
        break;
}

print "<h3>You like $seeColor $seeShape</h3>";

?>
</p>
</body>
</html>
