<?php 
setcookie('csc401_test','Hi from Rick');
setcookie('csc401_test2','Hello again', time()+1000, null, null);
?>
<html>
<head>
<title>add cookie</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h1>Set Cookie<br>
</h1>
<p><a href="index.php">Return </a></p>
<p>&nbsp; </p>
</body>
</html>
