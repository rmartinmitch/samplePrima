<html>
<head>
<title>Hi User</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h1>Hi User</h1>
<h3>Receive Value from Form</h3>

<?php 
$x = $_GET["someData"];
$x = $_POST["someData"];

$userName = $_REQUEST["userName"];

print "<h3>Hi There, $userName!</h3>";
?>

</body>
</html>
