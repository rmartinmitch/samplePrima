<?php 

// Connect To Database
// *
// database location
$hostname="rmitchelle.db.4076890.hostedresource.com";
// database name    
$username="rmitchelle"; 
// database password  
$password="Rickm2424";
// database name    
$dbname="rmitchelle";    

// function to connect to the database locations
mysql_connect($hostname,$username, $password) OR DIE ("Connection Failed");
// connect to a specific database
mysql_select_db($dbname);

?>
