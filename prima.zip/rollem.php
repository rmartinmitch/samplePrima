<html>
<head>
<title>Roll Em</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h1>ONE TWO THREE!</h1>
<h4>Pick a Number</h4>
<p> 
  <?php 

$roll = rand(1,3);
print "<h4>You rolled a $roll</h4>";


if ($roll == 3) {
	print "<h4>Thats a Three</h4>";
	}
	
if ($roll == 1) {
	print "<h4>That's a One</h4>";
} else {
	print "<h4>That's not a One</h4>";
}

if ($roll == 1) {
	$binValue = "001";
} else if ($roll == 2) {
	$binValue = "010";
} else if ($roll == 3) {
	$binValue = "011";
} else {
	print "I don't know that one ...";
}
	
print "<h4>Im binary, that's $binValue</h4>";

switch ($roll) {
	case 1:
		$romValue = "I";
		break;
	case 2:
		$romValue = "II";
		break;	
	case 3:
		$romValue = "III";
		break;	
	default: print "This is an illegal die";
}
print "<h4>In Roman Numverals that's $romValue</h4>";

if (is_numeric($roll)) {
	print "<h4>Thats a number</h4>";
	} else {
	echo "<h4>Thats NOT a number</h4>";
	}
	
?>
  &nbsp;</p>
<p>Refresh this page to roll again</p>
<p>&nbsp;</p>
</body>
</html>
