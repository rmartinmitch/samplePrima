<html>
<head>
<title>update customer</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h1>Customer Update</h1>
<p>&nbsp;</p>
<?php 

// this connects To database
include('connectDb.php');


$cusLast = $_REQUEST["cusLast"];
$cusFirst = $_REQUEST["cusFirst"];
$cusZip = $_REQUEST["cusZip"];
$cusStreet= $_REQUEST["cusStreet"];
$cusSex = $_REQUEST["cusSex"];
$cusSource = $_REQUEST["cusSource"];
$cusAge= $_REQUEST["cusAge"];
$cusBirth = $_REQUEST["cusBirth"];
$cusComment = $_REQUEST["cusComment"];

$dt = date('Y-m-d');

// here I test the parm
// the action I take depends on if the parm is a(dd) or u(pdate)
if ($action == 'a') {
	$query = "insert into cusTab values (
		null, 
		'$cusLast', 
		'$cusFirst', 
		'$cusZip', 
		'$cusStreet', 
		'$cusSex', 
		'$cusSource', 
		'$cusAge', 
		'$cusBirth',
		'$cusComment',
		'$dt', 
		null
	)";

	mysql_query($query) or
	die(mysql_error());

	echo "<h3>Thanks " . $cusFirst . " " . $custast . " for entering your information</h3>";
}

// now check for an update
// I will use a set query to update the changed fields
// I also update the changed date field 
if ($action == 'u') {
	$query = "update cusTab
		set cusLast = '$cusLast',
		cusFirst = '$cusFirst', 
		cusZip = '$cusZip', 
		cusStreet = '$cusStreet', 
		cusSex = '$cusSex', 
		cusSource = '$cusSource',
		cusAge = '$cusAge',
		cusSource = '$cusSource',
		cusComment = '$cusComment ',
		cusUpdated = '$dt' 
		where cusNo = '$id'";
	mysql_query($query) or
		die(mysql_error());
	print "<h3>Update Successful</h3>";
} // end u

?>
<br>
<p><a href="customerAdd.php">Return</a></p>
<p>&nbsp; </p>
</body>
</html>
