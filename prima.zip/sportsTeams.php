<html>
<head>
<title>sample associative arrays</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h4>My Sports Teams</h4>

<?php 


// create associative array
$bostonCeltics = array("center"=>"Perkins", "powerForward"=>"Garnett", "smallForward"=>"Pierce", "shootingGuard"=>"Allen", "pointGuard"=>"Rondo", "sixthMan"=>"Davis"); 



//	For-each loop
echo "in entry sequence<br>";
foreach ($bostonCeltics as $key => $player) {
	echo $player . " is the starting  " . $key . " of the Boston Celtics<br>";
} // end foreach loop	

echo "<br><br>";



//      sort ascending
echo "in ascending sequence<br>";
asort($bostonCeltics);
foreach ($bostonCeltics as $key => $player) {
	echo $player . " is the starting  " . $key . " of the Boston Celtics<br>";
} // end foreach loop	

echo "<br><br>";



//      sort ascending
echo "in descending sequence<br>";
arsort($bostonCeltics);
foreach ($bostonCeltics as $key => $player) {
	echo $player . " is the starting  " . $key . " of the Boston Celtics<br>";
} // end foreach loop	

echo "<br><br>";



//      sort key
echo "in key ascending sequence<br>";
ksort($bostonCeltics);
foreach ($bostonCeltics as $key => $player) {
	echo $player . " is the starting  " . $key . " of the Boston Celtics<br>";
} // end foreach loop	


echo "<br><br>";
//      sort key
echo "in key descending sequence<br>";
krsort($bostonCeltics);
foreach ($bostonCeltics as $key => $player) {
	echo $player . " is the starting  " . $key . " of the Boston Celtics<br>";
} // end foreach loop


?>
<br><br>
<a href="index.php">return</a>
</body>
</html>
