<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>found the larger one</title>
</head>

<body>
<p>&nbsp;</p>
<p>
  <?php 


function larger($a,$b) {

	if ($a > $b) {
		$x = "Option A - " . $a . " - is larger than Option B - " . $b;
	}	
	if ($a < $b) {
		$x = "Option A - " . $a . " - is smaller than Option B - " . $b;
	}	
	if ($a == $b) {
		$x = "Option A - " . $a . " - is equal to Option B - " . $b;
	}	
	
	return $x;
	
} // end function

$optionA = $_REQUEST['optionA'];
$optionB = $_REQUEST['optionB'];

echo larger($optionA,$optionB);


?>
</p>
<p><a href="largerTest.html">return</a></p>
</body>
</html>
