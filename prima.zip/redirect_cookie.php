<?php 

if (!isset($_COOKIE['csc401_test'])) {
 $cookie_sw = 'y';
 } else {
$cookie_sw = 'n';
 } // end if
 
if ($cookie_sw == 'n') {
	header("location: http://www.endicott.edu");
	exit();
} // end if

?>


<html>
<head>
<title>redirect cookie</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

<p><a href="index.php">Return </a></p>
<p>&nbsp; </p>

You were NOT redirected

</body>
</html>
