<html>
<head>
<title>
My Team
</title>
</head>
<body>


<?php
$team = "Boston Celtics";


$celtics = array("center"=>"Perkins", "powerForward"=>"Garnett", "smallForward"=>"Pierce", "shootingGuard"=>"Allen", "pointGuard"=>"Rondo", "sixthMan"=>"Davis"); 

$arrlength = count($celtics);


/*
foreach ($players as $x=> $x_value){
	echo  "$x is a starting $x_value for the $team";
	echo "<br>";
	}
*/
echo "<p>";	

foreach ($celtics as $key => $player) {
	echo $player . " is the starting  " . $key . " of the Boston Celtics<br>";
} // end foreach loop	

	
?>

<p><a href="index.php">Return Home</a></p>
</body>
</html>