<html>
<head>
<title>Basic Loops</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h4>Basic Loops </h4>

<?php 

// create an array by assignment
$boyName [1] = 'Andy';
$boyName [2] = 'Bob';
$boyName [3] = 'Carl';
$boyName [4] = 'David';
$boyName [5] = 'Edward';




//for loop
// the i value is set as part of the loop
for ($i = 0; $i < 5; $i++) {
	echo "Record No " . $i . " is " . $boyName[$i] . "<br>";
} // end for loop

echo "<br><br>";




//corrected for loop
for ($i = 1; $i < 6; $i++) {
	echo "Record No " . $i . " is " . $boyName[$i] . "<br>";
} // end for loop

echo "<br><br>";

// how to read backward?





//reading a loop backward
for ($i = 5; $i > 0; $i--) {
	echo "Record No " . $i . " is " . $boyName[$i] . "<br>";
} // end for loop

echo "<br><br>";




// create an array with the 'array' function 
$girlName = array(Ann,Barb,Connie,Doreen,Edith);




// while loop
// the i value is set outside the loop
$i = 0;
while ($i < 5) {
	echo "Position " . $i . " is a girl named " . $girlName[$i] . "<br>";
	$i++;
} // end while loop

echo "<br><br>";

// how to read backwards?



// while loop backwards
$i = 4;
while ($i >= 0) {
	echo "Position " . $i . " is a girl named " . $girlName[$i] . "<br>";
	$i--;
} // end while loop

echo "<br><br>";



// more common way to create an associative array
$stateCap = array("Alaska"=>"Juneau", "Indiana"=>"Indianapolis", "Michigan"=>"Lansing", "Ohio"=>"Columbus"); 




//	For-each loop
foreach ($stateCap as $key => $city) {
	echo $city . " is the state capital of " . $key . "<br>";
} // end foreach loop	

echo "<br><br>";




// a cool function
asort($stateCap);
foreach ($stateCap as $key => $city) {
	echo $city . " is the state capital of " . $key . "<br>";
} // end foreach loop	

echo "<br><br>";




// and one more
ksort($stateCap);
foreach ($stateCap as $key => $city) {
	echo $key . "'s state capital is: " . $city . "<br>";
} // end foreach loop	



?>
<br><br>
<a href="index.php">return</a>
</body>
</html>
