<?php 
if (!isset($_COOKIE['csc401_test'])) {
 $cookie_sw = 'n';
 } else {
 $cookie_sw = 'y';
 } // end if
 
 if (!isset($_COOKIE['csc401_test2'])) {
 $cookie_sw2 = 'n';
 } else {
 $cookie_sw2 = 'y';
 } // end if
 
 
?>


<html>
<head>
<title>check cookie</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h1>Check Cookie<br>
</h1>
<p><a href="index.php">Return </a></p>
<p>&nbsp; </p>

<?php 

if ($cookie_sw == 'n') {
	print "No cookie was found<br>";
} else if ($cookie_sw == 'y') {
	print "The cookie was <i>{$_COOKIE['csc401_test']}</i><br>";
} else { 
	print "I am confused<br>";
} // end if

if ($cookie_sw2 == 'n') {
	print "No 2nd cookie was found<br>";
} else if ($cookie_sw2 == 'y') {
	print "The 2nd cookie was <i>{$_COOKIE['csc401_test2']}</i><br>";
} else { 
	print "I am even more confused<br>";
} // end if


?>

</body>
</html>
