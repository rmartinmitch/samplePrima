<html>
<head>
<title>Basic Array</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h4>Basic Array </h4>

<?php 

// create an array by assignment
$boyName[1] = 'Andy';
$boyName [2] = 'Bob';
$boyName [3] = 'Carl';
$boyName [4] = 'David';
$boyName [5] = 'Edward';

echo "$boyName[0]<br><br>";

$i = 4;
echo "$boyName[$i]<br><br>";


// create an array with the 'array' function 
$girlName = array(Ann,Barb,Connie,Doreen,Edith);
$i = 1;
echo "$girlName[$i]<br><br>";


//print array using print_r
echo "print the boy array<br>";
print_r ($boyName);

echo "<br><br>print the girl array<br>";
print_r ($girlName);


// a simple associative array
$stateCap["Alaska"] = "Juneau";
$stateCap["Indiana"] = "Indianapolis";
$stateCap["Michigan"] = "Lansing";

echo "<br><br>Alaska state cap is: ";
echo $stateCap["Alaska"] . "<br>";

echo "<br>print the state capital array<br>";
print_r ($stateCap);

// sort an array
echo "<br><br>sort an array<br>";
sort($boyName);
print_r ($boyName);
echo "<br>";
rsort($boyName);
print_r ($boyName);

// randomize
echo "<br><br>randomize an array<br>";
shuffle($boyName);
print_r ($boyName);
echo "<br>";
shuffle($boyName);
print_r ($boyName);

// count
$x = count($boyName);
$y = count($stateCap);
echo "<br><br>" . $x . "  values in boy array and " . $y . " values in state array"; 



?>
<br><br>
<a href="index.php">return</a>
</body>
</html>
