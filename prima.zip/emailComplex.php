<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>complexemail</title>
</head>

<body>

<?php
$to = "rmitchel@endicott.edu";
$to .= ", rmitchell@salemstate.edu";

$subject = "A Complex Email";
$message = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam ut nibh mauris, in hendrerit neque.\nMauris tristique lobortis tempor. Phasellus in arcu a enim imperdiet ornare. Aenean sit amet sodales magna. Maecenas tincidunt posuere malesuada. Donec et dolor non purus vulputate aliquet. Praesent hendrerit congue sodales. Maecenas in magna sit amet velit viverra venenatis non sed odio.\nSed consectetur ullamcorper augue, at porttitor dui mollis id. Fusce eu nunc et diam feugiat auctor sed at sapien. Vivamus felis tortor, accumsan ac vehicula id, placerat et nisi. Quisque risus velit, fringilla non aliquam vulputate, imperdiet ut turpis. Praesent hendrerit tincidunt adipiscing. Nulla bibendum vestibulum hendrerit. Suspendisse et semper ante.\n\nCras augue neque, laoreet sit amet pretium id, facilisis vehicula nunc.";
$headers = 'From: Rick M <rickm@shore.net>' . "\r\n";
$headers .= 'Cc: rmartinmitch@gmail.com' . "\r\n";
$headers .= 'Bcc: glendagull@gmail.com' . "\r\n";


mail($to,$subject,$message,$headers);

echo "<h3>Email sent to " . $to . "</h3>";

?> 


</body>
</html>
