<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

<head>

<title>Olivia Asaro</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

</head>

<body> 

<h1>URL Checker</h1>

<form action="thesisURL.php" method="get" name="form1">

Website: <input type="text" name="nameValue" size="25" maxlength="25"/>

<input type="submit" name="Submit" value="Submit" />

</form> 

<p><a href="index.html">Return</a></p>

</body>

</html>

