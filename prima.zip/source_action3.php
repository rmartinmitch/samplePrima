<html>
<head>
<title>update source</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h1>Update Source</h1>
<p>&nbsp;</p>
<?php 

// this connects To database
include('connectDb.php');


$srcName = $_REQUEST["srcName"];
$srcComment = $_REQUEST["srcComment"];

$dt = date('Y-m-d');

$action = $_REQUEST["action"];
$id = $_REQUEST["id"];

// here I test the parm
// the action I take depends on if the parm is a(dd) or u(pdate)
if ($action == 'a') {
	$query = "insert into srcTab values (
		null, 
		'$srcName', 
		'$srcComment', 
		'$dt', 
		null
	)";

	mysql_query($query) or
		die(mysql_error());

	echo "<h4>Source >> " . $srcName . " - added</h4>";
}

// now check for an update
// I will use a set query to update the changed fields
// I also update the changed date field 
if ($action == 'u') {
	$query = "update srcTab
		set srcName = '$srcName',
		srcComment = '$srcComment ',
		srcUpdated = '$dt' 
		where srcID = '$id'";
	mysql_query($query) or
		die(mysql_error());
	print "<h4>Update Successful</h4>";
} // end u

if ($action == 'd') {
// this is a delete
// so perform a delete query
		$query = "delete from srcTab
		where srcID = '$id'";
		$result = mysql_query($query)
			 or die("query failed:" . mysql_error());
	print "<h4>Delete Successful</h4>";
} 
?>
<br>
<p><a href="source_list3.php">Return</a></p>
<p>&nbsp;  </p>
</body>
</html>
