<?php
session_start();
if (empty($_SESSION['user']))
{$_SESSION['user'] = 'rick'; }; // end if
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<p>You have logged in<br />
</p>
<p>(note &gt;&gt; in a real-world application you would have accepted a user id and password and verified on a database)</p>
<p><a href="sessionExample.html">return</a></p>
<p>&nbsp;</p>
</body>

</html>
