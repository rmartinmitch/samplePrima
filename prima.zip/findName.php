<html>
<head>
<title>string testing</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<h1>String Results
</h1>
  <br>
 <?php 
$yourName = $_REQUEST["yourName"];
$len = strlen($yourName);
$pos = strpos($yourName, ",");
$firstN = substr($yourName,$pos+1);
$lastN = substr($yourName,0,$pos);



echo "The field length is: " . $len . "<br>";
echo "The comma is at: " . $pos . "<br>";
echo "First name is: " . $firstN . "<br>";
echo "Last name is: " . $lastN . "<br>";
echo "Hello " . $firstN . " " . $lastN;


?>

<p><a href="stringExercise.html">return</a> </p>
</body>
</html>
